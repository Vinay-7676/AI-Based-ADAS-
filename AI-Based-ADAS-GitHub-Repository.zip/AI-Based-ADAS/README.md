# AI-Based ADAS Prototype

An educational Advanced Driver Assistance System (ADAS) prototype using Python, OpenCV and YOLOv8. It processes a webcam or road video, detects common road users, estimates lane boundaries, and displays basic visual warnings.

> **Safety notice:** This is a learning/demo project only. It is not automotive-grade software and must never be used to make real driving, braking, steering, or safety decisions. Lane detection and collision warnings are approximate and can fail in poor lighting, weather, camera angles, and unusual road layouts.

## Features

- Vehicle and pedestrian detection using a pretrained YOLOv8 model.
- Basic lane-line estimation using OpenCV (grayscale, blur, Canny edges, region of interest and Hough lines).
- Approximate forward-object warning based on bounding-box size and position.
- Live display with bounding boxes, lane overlay and warning banner.
- Supports webcam, video file, and optional output-video saving.

## Requirements

- Python 3.9–3.12 recommended
- Webcam or an MP4 road video
- Internet connection on first run if YOLO weights need to download

## Setup

```bash
# 1. Create and activate a virtual environment
python -m venv .venv

# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate

# 2. Install dependencies
pip install -r requirements.txt
```

## Run

Use webcam (camera index 0):

```bash
python main.py --source 0
```

Use a video file:

```bash
python main.py --source input/road_video.mp4
```

Save annotated output:

```bash
python main.py --source input/road_video.mp4 --save output/adas_output.mp4
```

Choose a smaller/faster YOLO model:

```bash
python main.py --source 0 --model yolov8n.pt
```

Press **Q** or **Esc** to quit the display.

## Project structure

```text
AI-Based-ADAS/
├── adas/
│   ├── __init__.py
│   ├── lane_detection.py
│   ├── object_detection.py
│   └── warnings.py
├── input/                 # Put your own road video here
├── output/                # Annotated videos are saved here
├── main.py
├── requirements.txt
├── .gitignore
└── README.md
```

## How it works

1. OpenCV reads frames from the camera/video.
2. YOLO detects objects such as cars, motorcycles, buses, trucks and people.
3. The lane module estimates left/right lane lines from edges in a lower-frame road region.
4. The warning module flags a large vehicle/person bounding box near the image centre as a possible forward hazard.
5. OpenCV overlays labels and warnings on the frame.

## Important limitations

- The lane detector is a simple Hough-line demonstration; it is not robust to curved, faded, occluded or complex lane markings.
- The warning logic uses image-space bounding-box size and location, **not calibrated distance, time-to-collision, radar, or depth**.
- YOLO results depend on model quality, camera position and environmental conditions.
- No vehicle control, steering, braking, CAN communication or ECU integration is implemented.

## Suggested future improvements

- Train/test on a suitable driving dataset (e.g. BDD100K or KITTI) and report precision/recall.
- Add camera calibration and perspective transformation for lane geometry.
- Use a depth-estimation model or calibrated stereo camera for distance estimation.
- Estimate time-to-collision using tracked objects and measured ego-vehicle speed.
- Add temporal tracking (e.g. ByteTrack) to reduce flicker.
- Evaluate in varied weather, lighting and road conditions.

## GitHub upload

Create a new empty repository on GitHub, then run these commands from this project folder:

```bash
git init
git add .
git commit -m "Initial AI-based ADAS prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/AI-Based-ADAS.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.
