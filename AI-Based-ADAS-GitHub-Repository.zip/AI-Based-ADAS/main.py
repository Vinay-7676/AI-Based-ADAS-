import argparse
import os
import cv2

from adas.lane_detection import detect_lanes
from adas.object_detection import ObjectDetector
from adas.warnings import find_forward_hazards


def parse_source(value):
    return int(value) if value.isdigit() else value


def main():
    parser = argparse.ArgumentParser(
        description="Educational AI-Based ADAS prototype"
    )
    parser.add_argument("--source", default="0",
                        help="Camera index (0) or path to a video file")
    parser.add_argument("--model", default="yolov8n.pt",
                        help="Ultralytics YOLO model/weights path")
    parser.add_argument("--conf", type=float, default=0.35,
                        help="Detection confidence threshold")
    parser.add_argument("--save", default=None,
                        help="Optional output video path, e.g. output/result.mp4")
    args = parser.parse_args()

    source = parse_source(args.source)
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise SystemExit(f"Error: could not open video source: {source}")

    detector = ObjectDetector(args.model, args.conf)
    writer = None
    window_name = "AI-Based ADAS Prototype"

    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break

            frame, lane_count = detect_lanes(frame)
            detections = detector.detect(frame)
            hazards = find_forward_hazards(detections, frame.shape)

            for item in detections:
                x1, y1, x2, y2 = item["box"]
                label = f'{item["label"]} {item["confidence"]:.2f}'
                color = (0, 200, 255)
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                cv2.putText(frame, label, (x1, max(20, y1 - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

            if hazards:
                message = "WARNING: POSSIBLE FORWARD HAZARD"
                cv2.rectangle(frame, (0, 0), (frame.shape[1], 42),
                              (0, 0, 180), -1)
                cv2.putText(frame, message, (12, 29),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                            (255, 255, 255), 2)
            else:
                cv2.putText(frame, "Status: No heuristic warning",
                            (12, 30), cv2.FONT_HERSHEY_SIMPLEX,
                            0.65, (0, 220, 0), 2)

            cv2.putText(frame, f"Objects: {len(detections)} | Lane lines: {lane_count}",
                        (12, frame.shape[0] - 15),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)

            if args.save:
                if writer is None:
                    output_dir = os.path.dirname(args.save)
                    if output_dir:
                        os.makedirs(output_dir, exist_ok=True)
                    fps = cap.get(cv2.CAP_PROP_FPS)
                    if not fps or fps <= 0 or fps > 120:
                        fps = 25.0
                    height, width = frame.shape[:2]
                    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                    writer = cv2.VideoWriter(args.save, fourcc, fps,
                                              (width, height))
                writer.write(frame)

            cv2.imshow(window_name, frame)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
    finally:
        cap.release()
        if writer is not None:
            writer.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
