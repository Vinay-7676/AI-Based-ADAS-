import cv2
import numpy as np


def detect_lanes(frame):
    """Return a frame with basic Hough-line lane estimates overlaid.

    This is a classroom demonstration, not a robust lane-detection system.
    """
    height, width = frame.shape[:2]
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 50, 150)

    mask = np.zeros_like(edges)
    polygon = np.array([[
        (int(width * 0.08), height),
        (int(width * 0.42), int(height * 0.55)),
        (int(width * 0.58), int(height * 0.55)),
        (int(width * 0.95), height),
    ]], dtype=np.int32)
    cv2.fillPoly(mask, polygon, 255)
    cropped = cv2.bitwise_and(edges, mask)

    lines = cv2.HoughLinesP(
        cropped, rho=1, theta=np.pi / 180, threshold=35,
        minLineLength=max(25, width // 12), maxLineGap=100
    )

    left, right = [], []
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            if x2 == x1:
                continue
            slope = (y2 - y1) / (x2 - x1)
            if abs(slope) < 0.35:
                continue
            (left if slope < 0 else right).append((x1, y1, x2, y2))

    overlay = frame.copy()
    lane_segments = []
    for group in (left, right):
        if not group:
            continue
        xs, ys = [], []
        for x1, y1, x2, y2 in group:
            xs.extend([x1, x2])
            ys.extend([y1, y2])
        slope, intercept = np.polyfit(ys, xs, 1)
        y_bottom = height
        y_top = int(height * 0.58)
        x_bottom = int(slope * y_bottom + intercept)
        x_top = int(slope * y_top + intercept)
        x_bottom = max(0, min(width - 1, x_bottom))
        x_top = max(0, min(width - 1, x_top))
        lane_segments.append(((x_bottom, y_bottom), (x_top, y_top)))

    for start, end in lane_segments:
        cv2.line(overlay, start, end, (0, 255, 0), 8)

    return cv2.addWeighted(frame, 0.85, overlay, 0.15, 0), len(lane_segments)
