def find_forward_hazards(detections, frame_shape, area_threshold=0.075):
    """Heuristic warning only; this does not calculate real-world distance."""
    height, width = frame_shape[:2]
    image_area = float(height * width)
    hazards = []

    for item in detections:
        x1, y1, x2, y2 = item["box"]
        box_area = max(0, x2 - x1) * max(0, y2 - y1)
        center_x = (x1 + x2) / 2
        near_image_center = width * 0.30 <= center_x <= width * 0.70
        large_in_frame = box_area / image_area >= area_threshold
        if near_image_center and large_in_frame:
            hazards.append(item)

    return hazards
