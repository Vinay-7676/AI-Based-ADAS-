from ultralytics import YOLO

# COCO class IDs used by the pretrained YOLO models.
ROAD_USER_CLASSES = {
    0: "person",
    2: "car",
    3: "motorcycle",
    5: "bus",
    7: "truck",
}


class ObjectDetector:
    def __init__(self, model_name="yolov8n.pt", confidence=0.35):
        self.model = YOLO(model_name)
        self.confidence = confidence

    def detect(self, frame):
        results = self.model.predict(
            source=frame,
            conf=self.confidence,
            classes=list(ROAD_USER_CLASSES.keys()),
            verbose=False
        )
        detections = []
        if not results:
            return detections

        for box in results[0].boxes:
            class_id = int(box.cls[0].item())
            label = ROAD_USER_CLASSES.get(class_id, "object")
            confidence = float(box.conf[0].item())
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            detections.append({
                "label": label,
                "confidence": confidence,
                "box": (x1, y1, x2, y2),
            })
        return detections
